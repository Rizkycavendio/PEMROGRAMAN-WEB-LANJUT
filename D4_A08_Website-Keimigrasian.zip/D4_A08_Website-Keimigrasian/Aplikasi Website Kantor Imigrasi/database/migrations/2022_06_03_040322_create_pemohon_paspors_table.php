<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePemohonPasporsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pemohon_paspors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id');
            $table->foreignId('kewarganegaraan_id');
            $table->foreignId('pekerjaan_id');
            $table->string('img_kk');
            $table->string('img_ktp');
            $table->string('img_akte');
            $table->string('nama');
            $table->string('tempat_lahir');
            $table->date('tggl_lahir');
            $table->date('tggl_pengajuan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pemohon_paspors');
    }
}
