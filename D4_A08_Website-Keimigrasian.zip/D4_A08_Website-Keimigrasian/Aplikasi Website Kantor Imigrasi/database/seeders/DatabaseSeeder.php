<?php

namespace Database\Seeders;

use App\Models\Feedback;
use App\Models\User;
use App\Models\Pekerjaan;
use App\Models\Kewarganegaraan;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'nik' => '20051397011',
            'nama' => 'Muhammad Rizky Cavendio',
            'kewarganegaraan_id' => 1,
            'pekerjaan_id' => 6,
            'no_telp' => '081281058588',
            'email' => 'mrc.dio2001@gmail.com',
            'password' => bcrypt('12345'),
            'jenis_kelamin' => 'Laki-laki'
        ]);

        Feedback::create([
            'user_id' => 1,
            'ulasan' => 'Dengan adanya sistem online mempermudah kami untuk mengurus paspor'
        ]);

        Kewarganegaraan::create([
            'kewarganegaraan' => 'WNI'
        ]);

        Kewarganegaraan::create([
            'kewarganegaraan' => 'WNA'
        ]);

        Pekerjaan::create([
            'pekerjaan' => 'Pegawai Negeri',
        ]);

        Pekerjaan::create([
            'pekerjaan' => 'Pegawai Swasta',
        ]);

        Pekerjaan::create([
            'pekerjaan' => 'Wiraswasta',
        ]);

        Pekerjaan::create([
            'pekerjaan' => 'Pedagang',
        ]);

        Pekerjaan::create([
            'pekerjaan' => 'Pengajar',
        ]);

        Pekerjaan::create([
            'pekerjaan' => 'Pelajar/Mahasiswa',
        ]);

        Pekerjaan::create([
            'pekerjaan' => 'Lainnya',
        ]);
    }
}
