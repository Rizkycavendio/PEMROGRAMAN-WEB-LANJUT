<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\PemohonPaspor;
use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\UpdatePemohonPasporRequest;

class PemohonPasporController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('paspor/pemohon', [
            'title' => 'Pengajuan Paspor'
        ]);
    }
}
