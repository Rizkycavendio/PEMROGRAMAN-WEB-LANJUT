<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Feedback;
use Illuminate\Http\Request;

class FeedbackController extends Controller
{
    public function index()
    {
        return view('feedback/index', [
            'title' => 'Indeks Kepuasan Masyarakat',
            'user' => User::all(),
            'feedbacks' => Feedback::latest()->get(),
        ]);
    }
}
