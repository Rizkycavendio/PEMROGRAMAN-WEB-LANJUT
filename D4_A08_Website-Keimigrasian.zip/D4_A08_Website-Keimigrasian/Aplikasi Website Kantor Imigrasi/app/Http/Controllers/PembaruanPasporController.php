<?php

namespace App\Http\Controllers;

use App\Models\PembaruanPaspor;
use App\Http\Requests\StorePembaruanPasporRequest;
use App\Http\Requests\UpdatePembaruanPasporRequest;

class PembaruanPasporController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorePembaruanPasporRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorePembaruanPasporRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PembaruanPaspor  $pembaruanPaspor
     * @return \Illuminate\Http\Response
     */
    public function show(PembaruanPaspor $pembaruanPaspor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PembaruanPaspor  $pembaruanPaspor
     * @return \Illuminate\Http\Response
     */
    public function edit(PembaruanPaspor $pembaruanPaspor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatePembaruanPasporRequest  $request
     * @param  \App\Models\PembaruanPaspor  $pembaruanPaspor
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatePembaruanPasporRequest $request, PembaruanPaspor $pembaruanPaspor)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PembaruanPaspor  $pembaruanPaspor
     * @return \Illuminate\Http\Response
     */
    public function destroy(PembaruanPaspor $pembaruanPaspor)
    {
        //
    }
}
