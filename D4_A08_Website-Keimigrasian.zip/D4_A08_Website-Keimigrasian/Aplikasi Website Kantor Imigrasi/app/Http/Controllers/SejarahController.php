<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SejarahController extends Controller
{
    public function index()
    {
        return view('sejarah/index', [
            'title' => 'Sejarah'
        ]);
    }
}
