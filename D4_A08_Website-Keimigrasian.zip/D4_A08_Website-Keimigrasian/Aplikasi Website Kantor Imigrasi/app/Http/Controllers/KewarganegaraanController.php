c<?php

    namespace App\Http\Controllers;

    use App\Models\Kewarganegaraan;
    use App\Http\Requests\StoreKewarganegaraanRequest;
    use App\Http\Requests\UpdateKewarganegaraanRequest;

    class KewarganegaraanController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\Http\Response
         */
        public function index()
        {
            //
        }

        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\Http\Response
         */
        public function create()
        {
            //
        }

        /**
         * Store a newly created resource in storage.
         *
         * @param  \App\Http\Requests\StoreKewarganegaraanRequest  $request
         * @return \Illuminate\Http\Response
         */
        public function store(StoreKewarganegaraanRequest $request)
        {
            //
        }

        /**
         * Display the specified resource.
         *
         * @param  \App\Models\Kewarganegaraan  $kewarganegaraan
         * @return \Illuminate\Http\Response
         */
        public function show(Kewarganegaraan $kewarganegaraan)
        {
            //
        }

        /**
         * Show the form for editing the specified resource.
         *
         * @param  \App\Models\Kewarganegaraan  $kewarganegaraan
         * @return \Illuminate\Http\Response
         */
        public function edit(Kewarganegaraan $kewarganegaraan)
        {
            //
        }

        /**
         * Update the specified resource in storage.
         *
         * @param  \App\Http\Requests\UpdateKewarganegaraanRequest  $request
         * @param  \App\Models\Kewarganegaraan  $kewarganegaraan
         * @return \Illuminate\Http\Response
         */
        public function update(UpdateKewarganegaraanRequest $request, Kewarganegaraan $kewarganegaraan)
        {
            //
        }

        /**
         * Remove the specified resource from storage.
         *
         * @param  \App\Models\Kewarganegaraan  $kewarganegaraan
         * @return \Illuminate\Http\Response
         */
        public function destroy(Kewarganegaraan $kewarganegaraan)
        {
            //
        }
    }
