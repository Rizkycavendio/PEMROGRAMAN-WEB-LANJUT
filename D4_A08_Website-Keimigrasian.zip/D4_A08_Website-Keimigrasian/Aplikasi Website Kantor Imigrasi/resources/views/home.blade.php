@extends('layouts/main')

@section('container')
    {{-- Gambar utama & text utama --}}
  <section id="intro" class="mb-5 mt-5">
    <div class="container-lg mt-5">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-5 text-center text-md-start">
              <h1>
                  <div class="display-5"> Selamat datang di website Kantor Imigrasi Surabaya</div>
              </h1>
              <p class="lead my-4 text-muted"> Direktorat Jenderal Imigrasi Kota Surabaya, Jawa Timur.
              </p>
            </div>
            <div class="col-md-5 text-center d-none d-md-block">
               <!-- gambar -->
               <span class="gambar" data-bs-placement="bottom">
                  <img class="img-fluid rounded" src="img/imigrasi1.jpg" alt="ebook cover">
              </span>
          </div>
        </div>
    </div>
</section>

{{-- fitur & layanan --}}
<section id="fitur" class="bg-dark mt-5">
    <div class="container-lg">
      <div class="text-center text-light mt-4">
          <h2>Layanan Kami</h2>
          <hr style="height:2px;border-width:0;color:rgb(255, 255, 255);background-color:#ffffff">
          <p class="lead text-light">Menghadirkan Layanan terbaik yang kami berikan untuk Anda</p>
      </div>
        <div class="row  my-5 align-items-center justify-content-center text-light">
            <div class="col-8 col-lg-4 col-xl-3">
                <div class="text-center" style="width: 18rem;">
                    <i class='fas fa-passport' style='font-size:100px;color:red'></i>
                    <div class="mt-3">
                      <h4>Permohonan Paspor</h4>  
                       <p class="card-text">Layanan bagi pembuatan paspor baru baik bagi WNI maupun WNA</p>
                    </div>
                  </div>
            </div>
            <div class="col-8 col-lg-4 col-xl-3">
              <div class="text-center" style="width: 18rem;">
                  <i class='fas fa-passport' style='font-size:100px;color:rgb(0, 81, 255)'></i>
                  <div class="mt-3">
                    <h4>Pembaruan Paspor</h4>  
                     <p class="card-text">Layanan bagi pembaruan paspor lama baik bagi WNI maupun WNA</p>
                  </div>
                </div>
            </div>
            <div class="col-8 col-lg-4 col-xl-3">
                <div class="text-center" style="width: 18rem;">
                    <i class='fas fa-book-reader' style='font-size:100px;color:rgb(0, 229, 23)'></i>
                    <div class="mt-3">
                      <h4>Berita</h4>  
                       <p class="card-text">Berita yang berisi informasi mengenai keimigrasian terkhusus di Surabaya Raya</p>
                    </div>
                  </div>
            </div>
        </div>
        <div class="row  my-5 align-items-center justify-content-center text-light">
            <div class="col-8 col-lg-4 col-xl-3">
                <div class="text-center" style="width: 18rem;">
                    <i class='fas fa-file-alt' style='font-size:100px;color:red'></i>
                    <div class="mt-3">
                      <h4>Cek Permohonan Paspor</h4>  
                       <p class="card-text">Untuk melakukan pengecekan permohonan paspor secara mandiri dapat dilakukan pada dashboard user</p>
                    </div>
                  </div>
            </div>
            <div class="col-8 col-lg-4 col-xl-3">
                <div class="text-center" style="width: 18rem;">
                    <i class='fas fa-file-alt' style='font-size:100px;color:rgb(0, 81, 255)'></i>
                    <div class="mt-3">
                      <h4>Cek Pembaruan Paspor</h4>  
                       <p class="card-text">Untuk melakukan pengecekan pembaruan paspor secara mandiri dapat dilakukan pada dashboard user</p>
                    </div>
                  </div>
            </div>
            <div class="col-8 col-lg-4 col-xl-3">
                <div class="text-center" style="width: 18rem;">
                    <i class='fas fa-chart-line' style='font-size:100px;color:rgb(229, 149, 0)'></i>
                    <div class="mt-3">
                      <h4>Indeks Kepuasan Masyarakat</h4>  
                       <p class="card-text">Penilaian dari masyarakat terhadap kinerja Kantor Imigrasi Surabaya</p>
                    </div>
                  </div>
            </div>
        </div>
    </div>
</section>

{{-- Tentang Kami --}}
<section id="tk" class="mt-4">
    <div class="container-lg">
        <div class="text-center mt-3">
            <h2>Tentang Kami</h2>
            <hr style="height:2px;border-width:0;color:rgb(0, 0, 0);background-color:#000000">
            <p class="lead text-muted">Informasi mengenai Kantor Imigrasi Surabaya</p>
        </div>
        <div class="row mt-5">
            <div class="col-md-6">
                <div class="left-image">
                    <img class="rounded" src="img/imigrasi1.jpg" alt="">
                </div>
            </div>
            <div class="col-md-6">
              <div class="right-image">
                  <h4>Tentang Kantor Imigrasi Surabaya...</h4>
                  <br>
                  <p> Terhitung sejak tanggal 10 Mei 2006, Kantor Imigrasi Kelas I Khusus TPI Surabaya termasuk salah satu Kantor Imigrasi yang ditingkatkan kelasnya dari Kelas I menjadi Kelas I Khusus berdasarkan Keputusan Menteri Hukum dan HAM RI No. M.01-PR.07.04 Tahun 2006. Perubahan status ini tentunya diharapkan dapat mengantisipasi peningkatan beban kerja dalam rangka memberikan pelayanan jasa keimigrasian kepada masyarakat yang dapat dipertanggung jawabkan kepada Pemerintah dan masyarakat itu sendiri. <br>
                  <br> Website Kantor Imigrasi Surabaya ini diharapkan agar pengguna layanan semakin dimudahkan karena tidak perlu bolak-balik ke Kantor Imigrasi hanya untuk melihat sampai dimana proses pembuatan paspor yang dimintanya. Pengguna layanan juga dapat mengajukan permohonan pembuatan paspor baru atau permohonan perpanjangan paspor dalam web ini. Pengguna layanan juga dapat melakukan upload data untuk permohonan pembuatan paspor baru atau permohonan perpanjangan paspor dalam website</p>
              </div>
          </div>
        </div>
    </div>
</section>
@endsection

 
      

