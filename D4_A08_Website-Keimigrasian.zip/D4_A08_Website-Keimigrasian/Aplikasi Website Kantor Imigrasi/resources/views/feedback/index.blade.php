@extends('layouts/main')

@section('container')
<section class="mt-3">
    <div class="container">
        <div class="text-center mt-5 mb-5">
            <h2>Indeks Kepuasan Kayarakat</h2>
            <hr style="height:2px;border-width:0;color:rgb(0, 0, 0);background-color:#000000">
            <p class="lead text-muted">Penilaian Masyarakat terkait kinerja kami</p>
        </div>
        <div class="row">
            @foreach ($feedbacks as $feedback)
            <div class="col-lg-4">
                <div class="card border-0 rounded shadow mb-3">
                    <div class="card-body">
                        <h5>Feedback pelayanan:</h5>                                                                                
                        <hr>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <div class="text-muted">{{ $feedback->created_at->diffForHumans() }}</div>
                        <div class="description mt-2">{{ $feedback->ulasan }}</div>   
                        <hr>
                        <div class="mb-2">
                            <span class="bi bi-person-circle"> 
                                <strong class="text-black-50 ml-2">{{ $feedback->user->nama }}</strong>
                                </span>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endsection

 
      

