@extends('dashboardUser/layouts/main')

@section('container')
<section class="mt-3">
    <div class="container">
        <h2>Feedback Anda: </h2>
      <hr>
        <a href="/dashboard/feedback/create" class="btn btn-info mb-3 text-light">Buat Ulasan +</a>
        <div class="row">
            <div class="col-lg-4">
                @foreach ($feedbacks as $feedback)
                <div class="card border-0 rounded shadow">
                    <div class="card-body">
                        <h5>Feedback pelayanan:</h5>                                                                                
                        <hr>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <div class="text-muted">{{ $feedback->created_at }}</div>
                        <div class="description mt-2">{{ $feedback->ulasan }}</div>   
                        <hr>
                        <div class="mb-3">
                            <span class="bi bi-person-circle"> 
                                <strong class="text-black-50 ml-2">{{ auth()->user()->nama }}</strong>
                                </span>
                        </div>
                        <div class="card-footer">
                            <div class="col-lg-6">
                                <a href="/dashboard/feedback/{{ $feedback->id }}/edit" class="text-light badge bg-success text-decoration-none" >EDIT  <span data-feather="edit"></span></a>
                                <form action="/dashboard/feedback/{{ $feedback->id }}" method="POST" class="d-inline">
                                  @method('delete')
                                  @csrf
                                  <button class="badge bg-danger border-0" onclick="return confirm('Serius ingin dihapus?')">HAPUS  <span data-feather="x-circle"></span></button>
                                 </form>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</section>

@endsection