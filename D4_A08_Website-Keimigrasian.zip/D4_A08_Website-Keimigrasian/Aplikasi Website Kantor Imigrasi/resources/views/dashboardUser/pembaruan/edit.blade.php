@extends('dashboardUser/layouts/main')

@section('container')
<div class="container-lg mt-3 mb-5">
  <h2>Edit Data Pembaruan Paspor</h2>
    <hr>
  <div class="row">
      <div class="col-lg-8">
          <main class="form-signin w-100 m-auto">
            @if (session()->has('loginError'))
              {{-- jika di session terdapat loginError, maka tampilkan di bawah ini --}}
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
              {{-- isi pesannya di bawhah ini, mengambil dari session loginError tadi di dalam LoginController --}}
                {{ session('loginError') }}   
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
             </div>
            @endif
            <form action="/dashboard/pembaruan/{{ $pembaruan->id }}" method="POST" enctype="multipart/form-data">
                @method('PUT')
              @csrf
              <div class="container">
                  <div class="mb-2">
                    <label for="nama" class="from-label">Nama:</label>
                    <input type="text" class="form-control @error('nama') is-invalid @enderror" id="nama" placeholder="Masukkan nama Anda..." name="nama" autofocus value="{{ old('nama', $pembaruan->nama) }}">
                    @error('nama')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                  <div class="mb-2">
                    <label for="slug" class="form-label">Pekerjaan:</label>
                    <select class="form-select" name="pekerjaan_id" >
                      @foreach ($pekerjaans as $pekerjaan)
                        @if (old('pekerjaan_id', $pembaruan->pekerjaan_id) == $pekerjaan->id)
                        <option value="{{ $pekerjaan->id }}"selected>{{ $pekerjaan->pekerjaan }}</option>  
                        @else
                        <option value="{{ $pekerjaan->id }}">{{ $pekerjaan->pekerjaan }}</option>  
                        @endif
                      @endforeach
                    </select>
                 </div>
                  <div class="mb-2">
                    <label for="slug" class="form-label">Kewarganegaraan:</label>
                    <select class="form-select" name="kewarganegaraan_id" >
                      @foreach ($kewarganegaraans as $kewarganegaraan)
                        @if (old('kewarganegaraan_id', $pembaruan->kewarganegaraan_id) == $kewarganegaraan->id)
                        <option value="{{ $kewarganegaraan->id }}"selected>{{ $kewarganegaraan->kewarganegaraan }}</option>  
                        @else
                        <option value="{{ $kewarganegaraan->id }}">{{ $kewarganegaraan->kewarganegaraan }}</option>  
                        @endif
                      @endforeach
                    </select>
                 </div>
                 <div class="mb-3">
                  <label for="img_ktp" class="form-label">Upload Kartu Identitas (KTP/Kartu Pelajar/SIM)</label>
                  @if($pembaruan->img_ktp)
                    <img src="{{ asset('storage/'.$pembaruan->img_ktp) }}" class="img-preview2 img-fluid mb-3 col-sm-5 d-block">
                    @endif
                  <input class="form-control  @error('img_ktp') is-invalid @enderror" type="file" id="img_ktp" name="img_ktp" onchange="previewImg_ktp()">
                    @error('img_ktp')
                        <div class="invalid-feedback">
                          {{ $message }}
                        </div>
                    @enderror
                 </div>
                 <div class="mb-2">
                    <label for="no_paspor" class="from-label">No Paspor:</label>
                    <input type="text" class="form-control @error('no_paspor') is-invalid @enderror" id="no_paspor" placeholder="Masukkan nomer paspor Anda..." name="no_paspor" autofocus value="{{ old('no_paspor', $pembaruan->no_paspor) }}">
                    @error('no_paspor')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                 <div class="mb-3">
                  <label for="img_paspor" class="form-label">Upload Paspor Lama</label>
                  @if($pembaruan->img_paspor)
                    <img src="{{ asset('storage/'.$pembaruan->img_paspor) }}" class="img-preview4 img-fluid mb-3 col-sm-5 d-block">
                  @endif
                  <input class="form-control  @error('img_paspor') is-invalid @enderror" type="file" id="img_paspor" name="img_paspor" onchange="previewImg_paspor()">
                    @error('img_paspor')
                        <div class="invalid-feedback">
                          {{ $message }}
                        </div>
                    @enderror
                 </div>
                 <div class="mb-2">
                    <label for="alasan" class="from-label">Alasan Pembaruan:</label>
                    <input type="text" class="form-control @error('alasan') is-invalid @enderror" id="alasan" placeholder="Masukkan alasan Anda..." name="alasan" value="{{ old('alasan', $pembaruan->alasan) }}">
                    @error('alasan')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                  <div class="mb-2">
                  <label for="tggl_pembaruan" class="from-label">Tanggal Pembaruan Paspor:</label>
                  <input type="date" class="form-control @error('tggl_pembaruan') is-invalid @enderror" id="tggl_pembaruan" placeholder="name@example.com" name="tggl_pembaruan" value="{{ old('tggl_pembaruan', $pembaruan->tggl_pembaruan) }}">
                  @error('tggl_pembaruan')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                  @enderror
                  </div>
                  <button class="btn btn-lg btn-success mt-3" type="submit">Perbaharui Data</button>
              </div>
            </form>
          </main>
      </div>
  </div>
</div>
@endsection


