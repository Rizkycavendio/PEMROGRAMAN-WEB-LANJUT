@extends('layouts/main')

@section('container')
<div class="container-lg mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <main class="form-signin w-100 m-auto">
              @if (session()->has('loginError'))
                {{-- jika di session terdapat loginError, maka tampilkan di bawah ini --}}
               <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{-- isi pesannya di bawhah ini, mengambil dari session loginError tadi di dalam LoginController --}}
                  {{ session('loginError') }}   
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
               </div>
              @endif
              <form action="/register" method="POST">
                @csrf
                <div class="card shadow border-0 p-5 mb-5">
                  <h1 class="h3 mb-3 fw-normal text-center">Registrasi</h1>
                  <div class="mb-3">
                  <label for="nik" class="from-label">NIK: </label>
                  <input type="text" class="form-control @error('nik') is-invalid @enderror" id="nik" placeholder="200513...." name="nik" value="{{ old('nik') }}" autofocus>
                    @error('nik')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                  <div class="mb-3">
                    <label for="nama" class="from-label">Nama: </label>
                    <input type="text" class="form-control @error('nik') is-invalid @enderror" id="nama" placeholder="Nama Anda...." name="nama" value="{{ old('nama') }}">
                    @error('nama')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                  <div class="mb-3">
                    <label for="no_telp" class="from-label">No. Telp</label>
                    <input type="text" class="form-control @error('no_telp') is-invalid @enderror" id="no_telp" placeholder="0812....." name="no_telp" value="{{ old('no_telp') }}">
                    @error('no_telp')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                  <div class="mb-3">
                    <label for="jenis_kelamin" class="from-label">Jenis Kelamin</label>
                    <input type="text" class="form-control @error('jenis_kelamin') is-invalid @enderror" id="jenis_kelamin" placeholder="Laki-laki/Perempuan" name="jenis_kelamin" value="{{ old('jenis_kelamin') }}">
                    @error('jenis_kelamin')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                  <div class="mb-3">
                    <label for="slug" class="form-label">Pekerjaan:</label>
                    <select class="form-select" name="pekerjaan_id" >
                      @foreach ($pekerjaans as $pekerjaan)
                        @if (old('pekerjaan_id') == $pekerjaan->id)
                        <option value="{{ $pekerjaan->id }}"selected>{{ $pekerjaan->pekerjaan }}</option>  
                        @else
                        <option value="{{ $pekerjaan->id }}">{{ $pekerjaan->pekerjaan }}</option>  
                        @endif
                      @endforeach
                    </select>
                 </div>
                 <div class="mb-3">
                  <label for="slug" class="form-label">Kewarganegaraan:</label>
                  <select class="form-select" name="kewarganegaraan_id" >
                    @foreach ($kewarganegaraans as $kewarganegaraan)
                      @if (old('kewarganegaraan_id') == $kewarganegaraan->id)
                      <option value="{{ $kewarganegaraan->id }}"selected>{{ $kewarganegaraan->kewarganegaraan }}</option>  
                      @else
                      <option value="{{ $kewarganegaraan->id }}">{{ $kewarganegaraan->kewarganegaraan }}</option>  
                      @endif
                    @endforeach
                  </select>
               </div>
                <div class="mb-3">
                  <label for="email" class="from-label">Email address</label>
                  <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" placeholder="name@gmail.com" name="email" value="{{ old('email') }}">
                  @error('email')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                  @enderror
                </div>
                <div class="mb-3">
                  <label for="password" class="from-label">Password</label>
                  <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                </div>
                <button class="w-100 btn btn-lg btn-warning mt-5" type="submit">Registrasi</button>
                <small class="d-block text-center mt-2">Sudah punya akun? <a href="/login"> Login di sini</a></small>
                </div>
              </form>
            </main>
        </div>
    </div>
</div>
@endsection
    