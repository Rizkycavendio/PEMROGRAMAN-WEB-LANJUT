

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Data Pembaruan Paspor Anda</h1>
  </div>

  <div class="table-responsive col-lg-12">
    <a href="/dashboard/pembaruan" class="btn btn-info mb-2">Kembali <--- </a>
    <table class="table table-info table-striped-columns table-bordered border-dark table-sm">
      <thead>
        <tr>
          <th scope="col">No. Antrian</th>
          <th scope="col">Nama</th>
          <th scope="col">NIK</th>
          <th scope="col">Pekerjaan</th>
          <th scope="col">Kewarganegaraan</th>
          <th scope="col">File Identitas (KTP\SIM\Lainnya)</th>
          <th scope="col">Nomer Paspor</th>
          <th scope="col">File Paspor</th>
          <th scope="col">Tanggal Pembaruan</th>
          <th scope="col">Alasan Pembaruan</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td><?php echo e($pembaruan->id); ?></td>
         <td><?php echo e($pembaruan->nama); ?></td>
         <td><?php echo e($pembaruan->user->nik); ?></td>
         <td><?php echo e($pembaruan->pekerjaan->pekerjaan); ?></td>
         <td><?php echo e($pembaruan->kewarganegaraan->kewarganegaraan); ?></td>
         <td><img src="<?php echo e(asset('storage/'.$pembaruan->img_ktp)); ?>" class="img-preview2 img-fluid" style="max-width: 100px"></td>
         <td><?php echo e($pembaruan->no_paspor); ?></td>
         <td><img src="<?php echo e(asset('storage/'.$pembaruan->img_paspor)); ?>" class="img-preview3 img-fluid" style="max-width: 100px"></td>
         <td><?php echo e($pembaruan->tggl_pembaruan); ?></td>
         <td><?php echo e($pembaruan->alasan); ?></td>
       </tr>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboardUser/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/dashboardUser/pembaruan/show.blade.php ENDPATH**/ ?>