

<?php $__env->startSection('container'); ?>
<div class="container-lg mt-3 mb-5">
    <h2>Tulis Ulasan Anda: </h2>
      <hr>
      <div class="row">
        <div class="col-lg-4">
            <form action="/dashboard/feedback" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card border-0 rounded shadow">
                    <div class="card-body">
                        <h5>Feedback pelayanan:</h5>
                        <hr>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <div class="mb-2 mt-2">
                            <label for="ulasan" class="from-label mb-2">Isi Ulasan:</label>
                            <textarea type="submit" class="form-control <?php $__errorArgs = ['ulasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ulasan" placeholder="Masukkan ulasan Anda..." name="ulasan" value="<?php echo e(old('ulasan')); ?>"></textarea>
                            <?php $__errorArgs = ['ulasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                              <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <hr>
                        <div class="mt-3">
                            <div class="col-lg-6">
                                <button class="border-0 text-light badge bg-info text-decoration-none" >KIRIM  <span data-feather="navigation"></span></button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboardUser/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/dashboardUser/feedback/create.blade.php ENDPATH**/ ?>