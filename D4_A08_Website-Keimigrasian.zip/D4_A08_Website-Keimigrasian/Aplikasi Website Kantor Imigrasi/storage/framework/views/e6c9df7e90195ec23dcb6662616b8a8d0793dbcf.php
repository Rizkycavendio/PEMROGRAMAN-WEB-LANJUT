

<?php $__env->startSection('container'); ?>
<div class="container-lg mt-5 mb-5">
  <div class="row justify-content-center">
      <div class="col-lg-6">
          <main class="form-signin w-100 m-auto">
            <?php if(session()->has('loginError')): ?>
              
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
              
                <?php echo e(session('loginError')); ?>   
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
             </div>
            <?php endif; ?>
            <form action="/pemohon" method="POST">
              <?php echo csrf_field(); ?>
              <div class="container">
                <div class="card shadow border-0 p-5">
                  <h1 class="h3 mb-3 fw-normal text-center">Form Pengajuan Paspor</h1>
                  <div class="form-floating">
                    <input type="text" class="form-control" id="nama" placeholder="Masukkan nama Anda..." name="nama">
                    <label for="nama">Nama</label>
                  </div>
                  <div class="form-floating">
                    <input type="text" class="form-control" id="tempat_lahir" placeholder="Masukkan tempat lahir Anda..." name="tempat_lahir">
                    <label for="tempat_lahir">Tempat Lahir</label>
                  </div>
                  <div class="form-floating">
                    <input type="date" class="form-control" id="tggl_lahir" placeholder="Masukkan tanggal lahir Anda..." name="tggl_lahir">
                    <label for="tggl_lahir">Tanggal Lahir</label>
                  </div>
                <div class="form-floating">
                  <input type="date" class="form-control" id="tggl_pengajuan" placeholder="name@example.com" name="tggl_pengajuan">
                  <label for="tggl_pengajuan">Tanggal Pengajuan Paspor</label>
                </div>
                <button class="btn btn-lg btn-danger mt-5" type="submit">Ajukan Paspor</button>
                </div>
              </div>
            </form>
          </main>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/paspor/pemohon.blade.php ENDPATH**/ ?>