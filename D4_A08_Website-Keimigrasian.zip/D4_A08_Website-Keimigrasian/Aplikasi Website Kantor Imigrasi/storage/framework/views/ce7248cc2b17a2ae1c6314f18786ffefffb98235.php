

<?php $__env->startSection('container'); ?>
<section class="mt-3">
    <div class="container">
        <h2>Feedback Anda: </h2>
      <hr>
        <a href="/dashboard/feedback/create" class="btn btn-info mb-3 text-light">Buat Ulasan +</a>
        <div class="row">
            <div class="col-lg-4">
                <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card border-0 rounded shadow">
                    <div class="card-body">
                        <h5>Feedback pelayanan:</h5>                                                                                
                        <hr>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <div class="text-muted"><?php echo e($feedback->created_at); ?></div>
                        <div class="description mt-2"><?php echo e($feedback->ulasan); ?></div>   
                        <hr>
                        <div class="mb-3">
                            <span class="bi bi-person-circle"> 
                                <strong class="text-black-50 ml-2"><?php echo e(auth()->user()->nama); ?></strong>
                                </span>
                        </div>
                        <div class="card-footer">
                            <div class="col-lg-6">
                                <a href="/dashboard/feedback/<?php echo e($feedback->id); ?>/edit" class="text-light badge bg-success text-decoration-none" >EDIT  <span data-feather="edit"></span></a>
                                <form action="/dashboard/feedback/<?php echo e($feedback->id); ?>" method="POST" class="d-inline">
                                  <?php echo method_field('delete'); ?>
                                  <?php echo csrf_field(); ?>
                                  <button class="badge bg-danger border-0" onclick="return confirm('Serius ingin dihapus?')">HAPUS  <span data-feather="x-circle"></span></button>
                                 </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboardUser/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/dashboardUser/feedback/index.blade.php ENDPATH**/ ?>