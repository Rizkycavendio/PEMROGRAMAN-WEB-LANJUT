

<?php $__env->startSection('container'); ?>
<section class="mt-3">
    <div class="container">
        <div class="text-center mt-5 mb-5">
            <h2>Indeks Kepuasan Kayarakat</h2>
            <hr style="height:2px;border-width:0;color:rgb(0, 0, 0);background-color:#000000">
            <p class="lead text-muted">Penilaian Masyarakat terkait kinerja kami</p>
        </div>
        <div class="row">
            <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="card border-0 rounded shadow mb-3">
                    <div class="card-body">
                        <h5>Feedback pelayanan:</h5>                                                                                
                        <hr>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <div class="text-muted"><?php echo e($feedback->created_at->diffForHumans()); ?></div>
                        <div class="description mt-2"><?php echo e($feedback->ulasan); ?></div>   
                        <hr>
                        <div class="mb-2">
                            <span class="bi bi-person-circle"> 
                                <strong class="text-black-50 ml-2"><?php echo e($feedback->user->nama); ?></strong>
                                </span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

 
      


<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/feedback/index.blade.php ENDPATH**/ ?>