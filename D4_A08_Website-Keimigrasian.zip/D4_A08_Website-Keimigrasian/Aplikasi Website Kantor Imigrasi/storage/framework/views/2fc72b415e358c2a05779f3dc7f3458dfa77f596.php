<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
      <ul class="nav flex-column">
        <h3 class="text-center">User: </h3>
        <hr>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" aria-current="page" href="/dashboard">
            <span data-feather="home" class="align-text-bottom"></span>
            Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard/pemohon/create') ? 'active' : ''); ?>" href="/dashboard/pemohon/create">
            <span data-feather="file" class="align-text-bottom"></span>
            Permohonan Paspor
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard/pemohon*') ? 'active' : ''); ?>" href="/dashboard/pemohon">
            <span data-feather="file" class="align-text-bottom"></span>
            Riwayat Permohonan
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard/pembaruan/create') ? 'active' : ''); ?>" href="/dashboard/pembaruan/create">
            <span data-feather="file-text" class="align-text-bottom"></span>
            Pembaruan Paspor
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard/pembaruan*') ? 'active' : ''); ?>" href="/dashboard/pembaruan">
            <span data-feather="file-text" class="align-text-bottom"></span>
            Riwayat Pembaruan
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard/feedback*') ? 'active' : ''); ?>" href="/dashboard/feedback">
            <span data-feather="trending-up" class="align-text-bottom"></span>
            Feedback User
          </a>
        </li>
      </ul>
    </div>
  </nav><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/dashboardUser/layouts/sidebar.blade.php ENDPATH**/ ?>