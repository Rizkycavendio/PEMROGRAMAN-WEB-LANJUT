

<?php $__env->startSection('container'); ?>
<div class="container mt-4">
  <h2>Permohonan Paspor Anda:</h2>
  <hr>
  <div class="col-lg-8">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success" role="alert">
      <?php echo e(session('success')); ?>

    </div>
  </div>
  <?php endif; ?>
  <div class="col-lg-8">
    <?php $__currentLoopData = $pemohons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemohon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card shadow border-0 p-4 mt-5">
      <h5>Data Permohonan Paspor</h5>
      <hr>
        <h6>No Antrian: <a class="text-muted text-decoration-none"><?php echo e($pemohon->id); ?> </a></h6>
        <h6>Nama: <a class="text-muted text-decoration-none"><?php echo e($pemohon->nama); ?> </a></h6> 
        <h6>Pekerjaan: <a class="text-muted text-decoration-none"><?php echo e($pemohon->pekerjaan->pekerjaan); ?> </a></h6>
        <h6>Kewarganegaraan: <a class="text-muted text-decoration-none"><?php echo e($pemohon->kewarganegaraan->kewarganegaraan); ?> </a></h6>
        <h6>Tanggal Pengajuan: <a class="text-muted text-decoration-none"><?php echo e($pemohon->tggl_pengajuan); ?> </a></h6>
        <br>
        <h5>Action:</h5>
        <div class="col-lg-8">
          <a href="/dashboard/pemohon/<?php echo e($pemohon->id); ?>/edit" class="text-light badge bg-success text-decoration-none" >Perbaharui Data  <span data-feather="edit"></span></a>
          <a href="/dashboard/pemohon/<?php echo e($pemohon->id); ?>" class="text-light badge bg-info text-decoration-none" >Lihat Data  <span data-feather="eye"></span></a>
          <form action="/dashboard/pemohon/<?php echo e($pemohon->id); ?>" method="POST" class="d-inline">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button class="badge bg-danger border-0" onclick="return confirm('Serius ingin dibatalkan?')">Batalkan  <span data-feather="x-circle"></span></button>
           </form>
        </div>
        
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboardUser/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/dashboardUser/pemohon/index.blade.php ENDPATH**/ ?>