

<?php $__env->startSection('container'); ?>
<div class="container-lg mt-5 mb-5">
  <div class="row justify-content-center">
      <div class="col-lg-4">
          <main class="form-signin w-100 m-auto">
            <?php if(session()->has('success')): ?>
            
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            
               <?php echo e(session('success')); ?>   
               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
             <?php endif; ?>
            <?php if(session()->has('loginError')): ?>
            
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            
               <?php echo e(session('loginError')); ?>   
               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
             <?php endif; ?>
            <form action="/login" method="POST">
              <?php echo csrf_field(); ?>
              <div class="card p-5 border-0 shadow">
                <h1 class="h3 mb-3 fw-normal text-center">Silahkan Login</h1>
              <div class="mb-3">
                <label for="nik" class="from-label">NIK: </label>
                  <input type="text" class="form-control" id="nik" placeholder="200513...." name="nik">
                </div>
              <div class="mb-3">
                <label for="email" class="from-label">Email: </label>
                <input type="email" class="form-control" id="email" placeholder="name@gmail.com" name="email">
              </div>
              <div class="mb-3">
                <label for="password" class="from-label">Password: </label>
                <input type="password" class="form-control" id="password" placeholder="Password" name="password">
              </div>
              <button class="w-100 btn btn-lg btn-warning mt-5" type="submit">Login</button>
              <small class="d-block text-center mt-2">Belum Registrasi? <a href="/register"> Registrasi di sini</a></small>
              </div>
            </form>
          </main>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/login/index.blade.php ENDPATH**/ ?>